"""Module to store version so it can be imported in other modules."""
__version__ = '1.0.3'
