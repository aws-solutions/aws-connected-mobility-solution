"""Util function that takes in data dict and converts all
keys to lowercase. This will make all keys consistant throughout
this deployment for all queries."""


def lowercase(data):
    """ Make dictionary lowercase """

    if isinstance(data, dict):
        return {key.lower(): lowercase(value) for key, value in data.items()}
    elif isinstance(data, (list, set, tuple)):
        data_type = type(data)
        return data_type(lowercase(obj) for obj in data)
    else:
        return data
